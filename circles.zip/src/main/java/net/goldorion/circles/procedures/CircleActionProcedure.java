package net.goldorion.circles.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class CircleActionProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, CommandContext<CommandSourceStack> arguments) {
		double radius = 0;
		double x2 = 0;
		double z2 = 0;
		double counter = 0;
		radius = DoubleArgumentType.getDouble(arguments, "radius");
		while (counter <= 360) {
			x2 = radius * Math.cos(counter);
			z2 = radius * Math.sin(counter);
			counter = counter + 1;
			world.setBlock(new BlockPos(x + x2, y, z + z2), (BlockStateArgument.getBlock(arguments, "block").getState()), 3);
		}
	}
}
