package net.goldorion.circles.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.commands.CommandSourceStack;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.DoubleArgumentType;

public class OvalActionProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, CommandContext<CommandSourceStack> arguments) {
		double x2 = 0;
		double z2 = 0;
		double counter = 0;
		double radX = 0;
		double radZ = 0;
		radX = DoubleArgumentType.getDouble(arguments, "radX");
		radZ = DoubleArgumentType.getDouble(arguments, "radZ");
		while (counter <= 360) {
			x2 = radX * Math.cos(counter);
			z2 = radZ * Math.sin(counter);
			counter = counter + 1;
			world.setBlock(new BlockPos(x + x2, y, z + z2), (BlockStateArgument.getBlock(arguments, "block").getState()), 3);
		}
	}
}
