
package net.goldorion.fluids.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.BlockPos;

import net.goldorion.fluids.init.FluidsModItems;
import net.goldorion.fluids.init.FluidsModFluids;
import net.goldorion.fluids.init.FluidsModBlocks;
import net.goldorion.fluids.fluid.attributes.SpecialWaterFluidAttributes;

public abstract class SpecialWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(FluidsModFluids.SPECIAL_WATER,
			FluidsModFluids.FLOWING_SPECIAL_WATER,
			SpecialWaterFluidAttributes
					.builder(new ResourceLocation("fluids:blocks/still_water"), new ResourceLocation("fluids:blocks/flowing_water"))

					.color(-13083194))
			.explosionResistance(100f).canMultiply()

			.bucket(FluidsModItems.SPECIAL_WATER_BUCKET).block(() -> (LiquidBlock) FluidsModBlocks.SPECIAL_WATER.get());

	private SpecialWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.DRIPPING_DRIPSTONE_WATER;
	}

	@Override
	public Vec3 getFlow(BlockGetter world, BlockPos pos, FluidState fluidstate) {
		return super.getFlow(world, pos, fluidstate).scale(-1);
	}

	public static class Source extends SpecialWaterFluid {
		public Source() {
			super();
		}

		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends SpecialWaterFluid {
		public Flowing() {
			super();
		}

		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
