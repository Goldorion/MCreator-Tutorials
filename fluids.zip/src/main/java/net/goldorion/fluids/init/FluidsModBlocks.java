
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.fluids.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.goldorion.fluids.block.SpecialWaterBlock;
import net.goldorion.fluids.block.SpecialLavaBlock;
import net.goldorion.fluids.block.AdvancedFluidBlock;
import net.goldorion.fluids.FluidsMod;

public class FluidsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FluidsMod.MODID);
	public static final RegistryObject<Block> SPECIAL_WATER = REGISTRY.register("special_water", () -> new SpecialWaterBlock());
	public static final RegistryObject<Block> SPECIAL_LAVA = REGISTRY.register("special_lava", () -> new SpecialLavaBlock());
	public static final RegistryObject<Block> ADVANCED_FLUID = REGISTRY.register("advanced_fluid", () -> new AdvancedFluidBlock());
}
