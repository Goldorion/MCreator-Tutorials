
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.fluids.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.goldorion.fluids.world.features.lakes.SpecialWaterFeature;
import net.goldorion.fluids.world.features.lakes.SpecialLavaFeature;
import net.goldorion.fluids.world.features.lakes.AdvancedFluidFeature;
import net.goldorion.fluids.FluidsMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class FluidsModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, FluidsMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> SPECIAL_WATER = register("special_water", SpecialWaterFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, SpecialWaterFeature.GENERATE_BIOMES, SpecialWaterFeature::placedFeature));
	public static final RegistryObject<Feature<?>> SPECIAL_LAVA = register("special_lava", SpecialLavaFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, SpecialLavaFeature.GENERATE_BIOMES, SpecialLavaFeature::placedFeature));
	public static final RegistryObject<Feature<?>> ADVANCED_FLUID = register("advanced_fluid", AdvancedFluidFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.LAKES, AdvancedFluidFeature.GENERATE_BIOMES, AdvancedFluidFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
