
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.fluids.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.goldorion.fluids.fluid.SpecialWaterFluid;
import net.goldorion.fluids.fluid.SpecialLavaFluid;
import net.goldorion.fluids.fluid.AdvancedFluidFluid;
import net.goldorion.fluids.FluidsMod;

public class FluidsModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, FluidsMod.MODID);
	public static final RegistryObject<Fluid> SPECIAL_WATER = REGISTRY.register("special_water", () -> new SpecialWaterFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_SPECIAL_WATER = REGISTRY.register("flowing_special_water",
			() -> new SpecialWaterFluid.Flowing());
	public static final RegistryObject<Fluid> SPECIAL_LAVA = REGISTRY.register("special_lava", () -> new SpecialLavaFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_SPECIAL_LAVA = REGISTRY.register("flowing_special_lava", () -> new SpecialLavaFluid.Flowing());
	public static final RegistryObject<Fluid> ADVANCED_FLUID = REGISTRY.register("advanced_fluid", () -> new AdvancedFluidFluid.Source());
	public static final RegistryObject<Fluid> FLOWING_ADVANCED_FLUID = REGISTRY.register("flowing_advanced_fluid",
			() -> new AdvancedFluidFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(SPECIAL_WATER.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_SPECIAL_WATER.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(SPECIAL_LAVA.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_SPECIAL_LAVA.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(ADVANCED_FLUID.get(), renderType -> renderType == RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_ADVANCED_FLUID.get(), renderType -> renderType == RenderType.translucent());
		}
	}
}
