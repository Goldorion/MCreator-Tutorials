
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.fluids.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.goldorion.fluids.item.SpecialWaterItem;
import net.goldorion.fluids.item.SpecialLavaItem;
import net.goldorion.fluids.item.AdvancedFluidItem;
import net.goldorion.fluids.FluidsMod;

public class FluidsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, FluidsMod.MODID);
	public static final RegistryObject<Item> SPECIAL_WATER_BUCKET = REGISTRY.register("special_water_bucket", () -> new SpecialWaterItem());
	public static final RegistryObject<Item> SPECIAL_LAVA_BUCKET = REGISTRY.register("special_lava_bucket", () -> new SpecialLavaItem());
	public static final RegistryObject<Item> ADVANCED_FLUID_BUCKET = REGISTRY.register("advanced_fluid_bucket", () -> new AdvancedFluidItem());
}
