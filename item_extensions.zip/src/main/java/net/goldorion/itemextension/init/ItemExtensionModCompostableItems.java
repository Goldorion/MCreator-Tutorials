
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.itemextension.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.block.ComposterBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ItemExtensionModCompostableItems {
	@SubscribeEvent
	public static void addComposterItems(FMLCommonSetupEvent event) {
		ComposterBlock.COMPOSTABLES.put(Items.DIAMOND, 1f);
		ComposterBlock.COMPOSTABLES.put(Blocks.DIRT.asItem(), 0.25f);
	}
}
