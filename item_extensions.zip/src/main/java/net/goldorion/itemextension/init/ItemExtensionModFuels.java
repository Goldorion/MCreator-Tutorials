
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.itemextension.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

import net.goldorion.itemextension.procedures.DiamondExtensionValueProcedure;

@Mod.EventBusSubscriber
public class ItemExtensionModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		ItemStack itemstack = event.getItemStack();
		if (itemstack.getItem() == Items.DIAMOND)
			event.setBurnTime((int) DiamondExtensionValueProcedure.execute(itemstack));
		else if (itemstack.getItem() == Blocks.DIRT.asItem())
			event.setBurnTime(20);
	}
}
