package net.goldorion.itemextension.procedures;

import net.minecraft.world.item.ItemStack;

public class DiamondExtensionValueProcedure {
	public static double execute(ItemStack itemstack) {
		return (itemstack).getCount() * 20;
	}
}
