
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.goldorion.teleporter.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.goldorion.teleporter.item.TeleporterItem;
import net.goldorion.teleporter.TeleporterMod;

public class TeleporterModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TeleporterMod.MODID);
	public static final RegistryObject<Item> TELEPORTER = REGISTRY.register("teleporter", () -> new TeleporterItem());
}
