package net.goldorion.teleporter.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

public class TeleporterRightclickedOnBlockProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity.isShiftKeyDown()) {
			itemstack.getOrCreateTag().putDouble("blockX", (entity.getX()));
			itemstack.getOrCreateTag().putDouble("blockY", (entity.getY()));
			itemstack.getOrCreateTag().putDouble("blockZ", (entity.getZ()));
			itemstack.getOrCreateTag().putBoolean("canTeleport", (true));
		}
	}
}
