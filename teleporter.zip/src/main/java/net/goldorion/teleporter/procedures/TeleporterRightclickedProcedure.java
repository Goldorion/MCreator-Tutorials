package net.goldorion.teleporter.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

public class TeleporterRightclickedProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getOrCreateTag().getBoolean("canTeleport") && !entity.isShiftKeyDown()) {
			{
				Entity _ent = entity;
				_ent.teleportTo((itemstack.getOrCreateTag().getDouble("blockX")), (itemstack.getOrCreateTag().getDouble("blockY") + 1),
						(itemstack.getOrCreateTag().getDouble("blockZ")));
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport((itemstack.getOrCreateTag().getDouble("blockX")),
							(itemstack.getOrCreateTag().getDouble("blockY") + 1), (itemstack.getOrCreateTag().getDouble("blockZ")), _ent.getYRot(),
							_ent.getXRot());
			}
		}
	}
}
